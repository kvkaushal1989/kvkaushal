<?php

class Packt_Helmet_Block_Product_View_Type_Simple extends Mage_Catalog_Block_Product_View_Abstract
{
}
