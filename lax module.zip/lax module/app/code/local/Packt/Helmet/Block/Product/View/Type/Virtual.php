<?php

class Packt_Helmet_Block_Product_View_Type_Virtual extends Mage_Catalog_Block_Product_View_Abstract
{

}
