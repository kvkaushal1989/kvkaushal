<?php
class Packt_Helmet_Block_Newproducts extends Mage_Catalog_Block_Product {

	public function getProducts(){
		$products = Mage::getModel('catalog/product')->getCollection()
		->addAttributeToSelect('*')
		->setOrder('created_at')
		->setPageSize(5);
		return $products;
	}

	public function getAllOptions(){
	 	$attribute = Mage::getModel('eav/config')->getAttribute('catalog_product', 'color'); 
	  	$allOptions = $attribute->getSource()->getAllOptions(true, true);
	  	foreach ($allOptions as $instance) {
	    	$id = $instance['value']; //id of the option
	    	$value = $instance['label']; //Label of the option
	  	}
	}

	public function getCategories(){
		  $categories = Mage::getModel('catalog/category')->getCollection()
		  ->addAttributeToSelect('id')
		  ->addAttributeToSelect('name')
		  ->addAttributeToSelect('url_key')
		  ->addAttributeToSelect('url')
		  ->addAttributeToSelect('is_active');
		  return $categories;
		 /* foreach ($categories as $category)
		  {
		      if ($category->getIsActive()) { // Only pull Active categories
		          $entity_id = $category->getId();
		          $name = $category->getName();
		          $url_key = $category->getUrlKey();
		          $url_path = $category->getUrl();
		      }
		  }*/
	}

	protected $_finalPrice = array();

    public function getProduct()
    {
        if (!$this->getData('product') instanceof Mage_Catalog_Model_Product) {
            if ($this->getData('product')->getProductId()) {
                $productId = $this->getData('product')->getProductId();
            }
            if ($productId) {
                $product = Mage::getModel('catalog/product')->load($productId);
                if ($product) {
                    $this->setProduct($product);
                }
            }
        }
        return $this->getData('product');
    }

    public function getPrice()
    {
        return $this->getProduct()->getPrice();
    }

    public function getFinalPrice()
    {
        if (!isset($this->_finalPrice[$this->getProduct()->getId()])) {
            $this->_finalPrice[$this->getProduct()->getId()] = $this->getProduct()->getFinalPrice();
        }
        return $this->_finalPrice[$this->getProduct()->getId()];
    }

    public function getPriceHtml($product)
    {
        $this->setTemplate('helmet/price.phtml');
        $this->setProduct($product);
        return $this->toHtml();
    }

    public function getOption(){
		$optionLabel = null;
	    $selectBox = null;
	    $selectBoxScript = null;

	    foreach ($_product->getOptions() as $_option) {
	        $optionLabel =  strtolower($_option->getTitle());
	        $values = $_option->getValues();
	        $selectBox .= '<label class="label">'.$_option->getTitle().'</label><br/><select name='.$optionLabel.' onchange='.$optionLabel.'Color("'.$optionLabel.'",this.value);>';
	        $selectBox .= '<option value="none">Please Select</option>';
	        foreach ($values as $v) {
	            $optionTitle = strtolower($v->getTitle());
	            $selectBox .= '<option value="'.$optionTitle.'">'.$optionTitle.'</option>';
	        }
	        $selectBoxScript .= '<script type="text/javascript"> // <![CDATA[ ';
	        $selectBoxScript .= 'function '.$optionLabel.'Color(imgid, color) {
	                                    document.getElementById(imgid).src ="'.Mage::getBaseUrl().'skin/frontend/default/universal/images/cascade/'.$optionLabel.'_" +color+".png";
	                                    opConfig.reloadPrice();
	                            }';

	        $selectBoxScript .= ' // ]]> </script>';
	        $selectBox .= '</select><br/><br/>';
	    }
	    return  $selectBox .' <br/>'.$selectBoxScript;
    }

}