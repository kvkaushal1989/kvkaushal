<?php
class Packt_Helmet_Block_Product_Send extends Mage_Catalog_Block_Product_Abstract
{
    public function __construct(){
        parent::__construct();
    }

    /**
     * Retrieve username for form field
     *
     * @return string
     */

    public function getUserName()
    {
        return Mage::getSingleton('customer/session')->getCustomer()->getName();
    }

    public function getEmail()
    {
        return (string)Mage::getSingleton('customer/session')->getCustomer()->getEmail();
    }

    public function getProductId()
    {
        return $this->getRequest()->getParam('id');
    }

    public function getMaxRecipients()
    {
        $sendToFriendModel = Mage::registry('send_to_friend_model');
        return $sendToFriendModel->getMaxRecipients();
    }
}
