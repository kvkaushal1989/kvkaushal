<?php
 class Packt_Helmet_Block_Product_View_Price extends Mage_Core_Block_Template
 {
    public function getPrice()
    {
        $product = Mage::registry('product');
        /*if($product->isConfigurable()) {
            $price = $product->getCalculatedPrice((array)$this->getRequest()->getParam('super_attribute', array()));
            return Mage::app()->getStore()->formatPrice($price);
        }*/

        return $product->getFormatedPrice();
    }
 }
