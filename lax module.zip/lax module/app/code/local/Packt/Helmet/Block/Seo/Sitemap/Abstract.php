<?php
abstract class Packt_Helmet_Block_Seo_Sitemap_Abstract extends Mage_Core_Block_Template
{

    /**
     * Init pager
     *
     * @param string $pagerName
     */
    public function bindPager($pagerName)
    {
        $pager = $this->getLayout()->getBlock($pagerName);
        /* @var $pager Mage_Page_Html_Pager */
        if ($pager) {
            $pager->setAvailableLimit(array(50 => 50));
            $pager->setCollection($this->getCollection());
            $pager->setShowPerPage(false);
        }
    }

    /**
     * Get item URL
     *
     * In most cases should be overriden in descendant blocks
     *
     * @param Varien_Object $item
     * @return string
     */
    public function getItemUrl($item)
    {
        return $item->getUrl();
    }

}
