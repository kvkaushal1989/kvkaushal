<?php

class Packt_Helmet_Block_Product_View_Options_Type_Default
    extends Mage_Catalog_Block_Product_View_Options_Abstract
{

}
