<?php
class Packt_Helmet_Model_Product extends Mage_Catalog_Model_Product {
	 public function getProductUrl($useSid = null)
    {
    	//return 'productview?id='.$useSid;
        return $this->getUrlModel()->getProductUrl($this, $useSid);
    }

    public function getUrlModel()
    {
        if ($this->_urlModel === null) {
            $this->_urlModel = Mage::getSingleton('catalog/factory')->getProductUrlInstance();
        }
        return $this->_urlModel;
    }
}