<?php

class Packt_Helmet_IndexController extends Mage_Core_Controller_Front_Action
{
    /**
     * Index action
     */
    public function indexAction()
    {
        $this->_redirect('/');
    }

    public function index1Action(){
		echo $this->__('All Credit Cards / Visa, Mastercard, AMEX, JCB, Diners (powered by Moneybookers) - International');
	}

	public function helloAction(){
		//echo 'Action hello in Helloworld IndexController';
		$this->loadLayout();
		$this->renderLayout();
	}
	public function productviewAction(){
		//echo 'Action hello in Helloworld IndexController';
		$productID = "asdfadsfdfs a";
		$this->loadLayout();
		$this->renderLayout();
	}
}
